/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.EmlpoyeeManagement;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author drexz
 */
public class  Attendent{

    @SuppressWarnings("UnusedAssignment")
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Office", "1102", "1102");
            Statement smt = cn.createStatement();

            Scanner sc = new Scanner(System.in);
            System.out.println("Press 1 To Insert Attendents Data");
            System.out.println("Press 2 To Update Attendents Data");
            System.out.println("Press 3 to Access Attendents Data");
            int i = sc.nextInt();
            switch (i) {
                case 1 ->                     {
                        System.out.println("Enter id");
                        int id = sc.nextInt();
                        System.out.println("Enter Name");
                        String name = sc.next();
                        System.out.println("Enter Wages");
                        float wages = sc.nextFloat();
                        i = smt.executeUpdate("call get_insert(" + id + ",'" + name + "'," + wages + ")");
                        ResultSet rs = smt.executeQuery("Select * from Attendents");
                        while (rs.next()) {
                            id = rs.getInt("Id");
                            name = rs.getString("Name");
                            String Wages = rs.getString("Wages");
                            
                            System.out.println(id + "," + name + "," + Wages);
                        }       cn.close();
                    }
                case 2 -> {
                    System.out.println("Press 1 To Update Name");
                    System.out.println("Press 2 to Update Wages");
                    i = sc.nextInt();
                    switch (i) {
                        case 1 ->                         {
                            System.out.print("Enter ID For Upgradation Of Name= ");
                            int id = sc.nextInt();
                            System.out.print("Enter Updated Name= ");
                            String name = sc.next();
                            i = smt.executeUpdate("call get_updateName('" + name + "'," + id + ")");
                            ResultSet rs = smt.executeQuery("Select * from Attendent");
                            while (rs.next()) {
                                id = rs.getInt("Id");
                                name = rs.getString("Name");
                                String Wages = rs.getString("Wages");
                                
                                System.out.println(id + "," + name + "," + Wages);
                            }   cn.close();
                        }
                        case 2 ->                         {
                            System.out.print("Enter ID For Upgradation Salary= ");
                            int id = sc.nextInt();
                            System.out.print("Enter Upgrade Wages= ");
                            float wages = sc.nextFloat();
                            i = smt.executeUpdate("call get_updateSalary(" + wages + "," + id + ")");
                            ResultSet rs = smt.executeQuery("Select * from Attendent");
                            while (rs.next()) {
                                id = rs.getInt("Id");
                                String name = rs.getString("Name");
                                String Wages = rs.getString("Wages");
                                
                                System.out.println(id + "," + name + "," + Wages);
                            }   cn.close();
                        }
                        default -> System.out.println("Please Press The Correct Buttton  1 OR 2");
                    }
                }

                case 3 ->                     {
                        System.out.print("Enter ID To Access Data Of Attendent= ");
                        int id = sc.nextInt();
                        i = smt.executeUpdate("call get_details(" + id + ")");
                        ResultSet rs = smt.executeQuery("select * from Attendent where id= " + id);
                        if (rs.next()) {
                            id = rs.getInt("Id");
                            String n = rs.getString("Name");
                            float s = rs.getFloat("Wages");
                            System.out.println(id + "," + n + "," + s);
                        }       cn.close();
                    }
                default -> System.out.println("Please Press The Correct Button  1,2 OR 3");
            }

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
            System.out.println(e.toString());
        }
    }

}
